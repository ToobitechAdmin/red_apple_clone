
		
		
	<?php include('section/header.php') ?>
	
	 <!----nav end---->
	 <!---home Start--->
	 <!---Banner start--->
	 <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
		<div class="carousel-indicators">
		   <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
		   <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
		</div>
		<div class="carousel-inner">
		   <div class="carousel-item active">
			  <img src="images/bannnner.jpg" class="img-fluid d-block w-100" alt="...">
		   </div>
		   <div class="carousel-item">
			  <img src="images/bannnner.jpg" class="img-fluid d-block w-100 "  alt="...">
		   </div>
		   <!-- <div class="carousel-item">
			  <img src="..." class="d-block w-100" alt="...">
			   </div> -->
		   <!-- <div class="carousel-item">
			  <img src="..." class="d-block w-100" alt="...">
			   </div> -->
		</div>
		<div class="container-fluid banner-bottom" data-aos="zoom-in">
		   <div class="row">
			  <div class=" col-lg-8 bannerbottom-colo">
				 <div class="row">
					<div class="col-md-4">
					   <div class="d-flex hver">
						  <div>
							 <i class="fa-solid fa-clock mb-2" style="font-size:22px; color: white;" id="iconnnn" ></i>
						  </div>
						  <div class="ps-4 pb-0">
							 <p class="iconheading p-0" >Opening Hours</p>
							 <div class="padddding">
								<span class="iconspan" >Fri 11:00 am - 12:00 am</span>
							 </div>
						  </div>
					   </div>
					</div>
					<!-- <div class="col-md-4">   <h5> <i class="fa-solid fa-location-dot" id="iconnnn" style="font-size: 22px; color: white;"></i> Trusted Partner </h5> </div> -->
					<div class="col-md-4">
					   <div class="d-flex ">
						  <div>
							 <i class="fa-solid fa-location-dot" id="iconnnn" style="font-size: 22px; color: white;"></i>
						  </div>
						  <div class="ps-4 pb-0">
							 <p class="iconheading p-0" >Address</p>
							 <div class="padddding">
								<span class="iconspan" >F-6 Markaz F 6 Markaz F-6..</span>
							 </div>
						  </div>
					   </div>
					</div>
					<!-- <div class="col-md-4">   <h5> <i class="fa-solid fa-square-phone" style="font-size: 22px; color: white;" id="iconnnn"></i> Trusted Partner</h5></div> -->
					<div class="col-md-4">
					   <div class="d-flex ">
						  <div>
							 <i class="fa-solid fa-square-phone" style="font-size: 22px; color: white;" id="iconnnn"></i>
						  </div>
						  <div class="ps-4 pb-0">
							 <p class="iconheading p-0" >Contact</p>
							 <div class="padddding">
								<span class="iconspan" >(000) 000-000-000</span>
							 </div>
						  </div>
					   </div>
					</div>
				 </div>
			  </div>
		   </div>
		</div>
		<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="visually-hidden">Previous</span>
		</button>
		<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="visually-hidden">Next</span>
		</button>
	 </div>
	 <!----Banner end--->

	 					<!---- for tags -->
		<?php include('section/banner-aftertag.php') ?>

						<!---- for tags -->

						<!------body-->

						<div class="container-fluid main">
    <div class="row">
        <div class="col-12" data-aos="zoom-out" data-aos-duration="500">
            <i class="fa-solid fa-location-dot" style="color: #ee6826; font-size: 33px;"></i> <span style="margin-left: 20px;" id="bodyspan">Delivering to: <strong> DHA - Defence Phase 03 </strong></span>
        </div>
    </div>
</div>

<!----body banner menu---->

<div class="container-fluid bodybanner">
    <div class="row" id="chatbazar">
        <div class="col-12" data-aos="zoom-in" data-aos-duration="500">
            <h1>Chaat bazzar</h1>
        </div>
    </div>
</div>

<!----body banner menu---->

<div class="container-fluid menu">
   
        <div class="row g-4" data-aos="fade-up" data-aos-duration="1000">
            <!---column--->

            <div class="col-12 col-md-6 col-lg-4" data-toggle="modal" data-target="#myModalprocliclcart">
                <div class="item">
                    <div class="row">
                        <div class="col-6 col-md-6">
							
                            <div><span>lorim ipsume</span></div>
                            <div class="bottem-text"><span>lorim ipsume</span></div>
                        </div>
						
                        <div class="col-6 col-md-6">
                            <img src="images/1.jpg" class="img-fluid w-100" id="menuimg" srcset="" />
                        </div>
                    </div>
                </div>
            </div>
            <!---column--->

            <!---column--->

            <div class="col-12 col-md-6 col-lg-4" data-toggle="modal" data-target="#myModalprocliclcart">
                <div class="item">
                    <div class="row">
                        <div class="col-6 col-md-6">
                            <div><span>lorim ipsume</span></div>
                            <div class="bottem-text"><span>lorim ipsume</span></div>
                        </div>
                        <div class="col-6 col-md-6">
                            <img src="images/2.jpg" class="img-fluid w-100" id="menuimg" srcset="" />
                        </div>
                    </div>
                </div>
            </div>
            <!---column--->

            <!---column--->

            <div class="col-12 col-md-6 col-lg-4" data-toggle="modal" data-target="#myModalmoreproduct-deltails">
                <div class="item">
                    <div class="row">
                        <div class="col-6 col-md-6">
                            <div><span>lorim ipsume</span></div>
                            <div class="bottem-text"><span>lorim ipsume</span></div>
                        </div>
                        <div class="col-6 col-md-6">
                            <img src="images/3.jpg" class="img-fluid w-100" id="menuimg" srcset="" />
                        </div>
                    </div>
                </div>
            </div>
            <!---column--->

            <!---column--->

            <div class="col-12 col-md-6 col-lg-4">
                <div class="item">
                    <div class="row">
                        <div class="col-6 col-md-6">
                            <div><span>lorim ipsume</span></div>
                            <div class="bottem-text"><span>lorim ipsume</span></div>
                        </div>
                        <div class="col-6 col-md-6">
                            <img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="" />
                        </div>
                    </div>
                </div>
            </div>
            <!---column--->

            <!---column--->

            <div class="col-12 col-md-6 col-lg-4">
                <div class="item">
                    <div class="row">
                        <div class="col-6 col-md-6">
                            <div><span>lorim ipsume</span></div>
                            <div class="bottem-text"><span>lorim ipsume</span></div>
                        </div>
                        <div class="col-6 col-md-6">
                            <img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="" />
                        </div>
                    </div>
                </div>
            </div>
            <!---column--->

            <!---column--->

            <div class="col-12 col-md-6 col-lg-4">
                <div class="item">
                    <div class="row">
                        <div class="col-6 col-md-6">
                            <div><span>lorim ipsume</span></div>
                            <div class="bottem-text"><span>lorim ipsume</span></div>
                        </div>
                        <div class="col-6 col-md-6">
                            <img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
</div>

<!---column--->

				

			</div>


			

		</div>
	</div>




		<!----body banner menu---->

		<div class="container-fluid bodybanner">
			<div class="row">
				<div class="col-12" data-aos="zoom-in" data-aos-duration="500">
	
					<h1>New Arrival</h1>
				</div>
			</div>
		</div>
	
		<!----body banner menu---->
	
		<div class="container-fluid menu">
		
			<div class="row g-4"  data-aos="fade-up" data-aos-duration="1000">
	
					<!---column--->
					
				<div class="col-12 col-md-6 col-lg-4  ">
					<div class="item">
					<div class="row ">
						<div class="col-6 col-md-6">
							<div><span>lorim ipsume</span></div>
							<div  class="bottem-text" ><span>lorim ipsume</span></div>
						</div>
						<div class="col-6  col-md-6">
							<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
						</div>
					</div>
				</div>
			</div>
					<!---column--->
	
	
	
						<!---column--->
			
						<div class="col-12 col-md-6 col-lg-4  ">
							<div class="item">
							<div class="row ">
								<div class="col-6 col-md-6">
									<div><span>lorim ipsume</span></div>
									<div  class="bottem-text" ><span>lorim ipsume</span></div>
								</div>
								<div class="col-6  col-md-6">
									<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
								</div>
							</div>
						</div>
					</div>
					
					<!---column--->
	
	
	
					<!---column--->
			
					<div class="col-12 col-md-6 col-lg-4  ">
						<div class="item">
						<div class="row ">
							<div class="col-6 col-md-6">
								<div><span>lorim ipsume</span></div>
								<div  class="bottem-text" ><span>lorim ipsume</span></div>
							</div>
							<div class="col-6  col-md-6">
								<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
							</div>
						</div>
					</div>
				</div>
				<!---column--->
	
				<!---column--->
			
				<div class="col-12 col-md-6 col-lg-4  ">
					<div class="item">
					<div class="row ">
						<div class="col-6 col-md-6">
							<div><span>lorim ipsume</span></div>
							<div  class="bottem-text" ><span>lorim ipsume</span></div>
						</div>
						<div class="col-6  col-md-6">
							<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
						</div>
					</div>
				</div>
			</div>
			<!---column--->
	
			<!---column--->
			
			<div class="col-12 col-md-6 col-lg-4  ">
				<div class="item">
				<div class="row ">
					<div class="col-6 col-md-6">
						<div><span>lorim ipsume</span></div>
						<div  class="bottem-text" ><span>lorim ipsume</span></div>
					</div>
					<div class="col-6  col-md-6">
						<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
					</div>
				</div>
			</div>
		</div>
		<!---column--->
	
	
		<!---column--->
			
		<div class="col-12 col-md-6 col-lg-4  ">
			<div class="item">
			<div class="row ">
				<div class="col-6 col-md-6">
					<div><span>lorim ipsume</span></div>
					<div  class="bottem-text" ><span>lorim ipsume</span></div>
				</div>
				<div class="col-6  col-md-6">
					<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
				</div>
			</div>
		</div>
	</div>
	<!---column--->
	
					
	
			
	
	
				
	
			</div>
		</div>








			<!----body banner menu---->

			<div class="container-fluid bodybanner" id="onlineexc">
				<div class="row">
					<div class="col-12" data-aos="zoom-in" data-aos-duration="500">
		
						<h1>online exclusive deals</h1>
					</div>
				</div>
			</div>
		
			<!----body banner menu---->
		
			<div class="container-fluid menu">
			
				<div class="row g-4" data-aos="fade-up" data-aos-duration="1000">
		
						<!---column--->
						
					<div class="col-12 col-md-6 col-lg-4  ">
						<div class="item">
						<div class="row ">
							<div class="col-6 col-md-6">
								<div><span>lorim ipsume</span></div>
								<div  class="bottem-text" ><span>lorim ipsume</span></div>
							</div>
							<div class="col-6  col-md-6">
								<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
							</div>
						</div>
					</div>
				</div>
						<!---column--->
		
		
		
							<!---column--->
				
							<div class="col-12 col-md-6 col-lg-4  ">
								<div class="item">
								<div class="row ">
									<div class="col-6 col-md-6">
										<div><span>lorim ipsume</span></div>
										<div  class="bottem-text" ><span>lorim ipsume</span></div>
									</div>
									<div class="col-6  col-md-6">
										<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
									</div>
								</div>
							</div>
						</div>
						<!---column--->
		
		
		
						<!---column--->
				
						<div class="col-12 col-md-6 col-lg-4  ">
							<div class="item">
							<div class="row ">
								<div class="col-6 col-md-6">
									<div><span>lorim ipsume</span></div>
									<div  class="bottem-text" ><span>lorim ipsume</span></div>
								</div>
								<div class="col-6  col-md-6">
									<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
								</div>
							</div>
						</div>
					</div>
					<!---column--->
		
					<!---column--->
				
					<div class="col-12 col-md-6 col-lg-4  ">
						<div class="item">
						<div class="row ">
							<div class="col-6 col-md-6">
								<div><span>lorim ipsume</span></div>
								<div  class="bottem-text" ><span>lorim ipsume</span></div>
							</div>
							<div class="col-6  col-md-6">
								<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
							</div>
						</div>
					</div>
				</div>
				<!---column--->
		
				<!---column--->
				
				<div class="col-12 col-md-6 col-lg-4  ">
					<div class="item">
					<div class="row ">
						<div class="col-6 col-md-6">
							<div><span>lorim ipsume</span></div>
							<div  class="bottem-text" ><span>lorim ipsume</span></div>
						</div>
						<div class="col-6  col-md-6">
							<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
						</div>
					</div>
				</div>
			</div>
			<!---column--->
		
		
			<!---column--->
				
			<div class="col-12 col-md-6 col-lg-4  ">
				<div class="item">
				<div class="row ">
					<div class="col-6 col-md-6">
						<div><span>lorim ipsume</span></div>
						<div  class="bottem-text" ><span>lorim ipsume</span></div>
					</div>
					<div class="col-6  col-md-6">
						<img src="images/mainpagelogo.png" class="img-fluid w-50" id="menuimg" srcset="">
					</div>
				</div>
			</div>
		</div>
		<!---column--->
		
						
		
					</div>
		
		
					
		
			
			</div>





		

	<!--model  for Man Menu ---->

	<?php include('section/left-tage.php') ?>



<?php include('section/right-nav.php') ?>
<!---Model right menu---->



<!--Model Cart---->
<?php include('section/cart.php') ?>
<!--Model Menu---->

<!---Model left side tag----->

   <!--preloader start-->
   <?php include('section/preloader.php') ?>
				<!--preloader end--->





<!--footer start-->
<?php include('section/product1-cart.php') ?>
				<!--footer end--->


				<!--footer start-->
<?php include('section/productmore-detail.php') ?>
				<!--footer end--->

				<!--footer start-->
				<?php include('section/footer.php') ?>
				<!--footer end--->







		
		
			
			
		

			
			<!-- model left side tag--->

		<!--proe loader-->

	  


		<!--preloader--->


    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
	<script src="js/script.js"></script>
	<script>
	


	  $ (document).ready (function () {
	$ (".modal a").not (".dropdown-toggle").on ("click", function () {
		$ (".modal").modal ("hide");
	
	
	});

	


	
});

wow = new WOW(
		{
		boxClass:     'wow',      // default
		animateClass: 'animated', // default
		offset:       0,          // default
		mobile:       true,       // default
		live:         true        // default
	  }
	  )
	  wow.init();
	</script>
  </body>
</html>