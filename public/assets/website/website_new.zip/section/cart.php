<div class="container">
				
			  <!-- Trigger the modal with a button -->
			  <!-- <button type="button" class="btn btn-info btn-lg btn-position" data-toggle="modal" data-target="#myModalcart">Click Me</button> -->
			
			  <!-- Modal -->
			  <div class="modal right fade" id="myModalcart" role="dialog">
				<div class="modal-dialog">
				
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">

						<h4 class="modal-title menu" style="float: left;" >Your Cart</h4>
					
						 <h4 class="modal-title menu" style="float: left;" >
							Total items: 2</h4>
						<button type="button" class="close " data-dismiss="modal" >&times;</button>
					</div>
					<div class="modal-body">
					 
						<div class="row">
							<div class="col-sm-12">
								<div class="table-responsive">
								<table class="table table-borderless table-responsive">
									<thead style="background-color: #f5f5f5;">
									  <tr>
										
										<th scope="col">Product Name</th>
										<th scope="col">Quantity</th>
										<th scope="col">Amount</th>
									  </tr>
									</thead>
									<tbody>
									  <tr>
										
										<td class=" w-50 mt-1"><div class="img-withdesc"> <img src="images/mainpagelogo.png" class="img-fluid w-25" alt=""> <div class="descr"> meethi puri <span class="badge badge-secondary"><i class="fa-solid fa-trash"></i> remove</span>  </div></div></td>
										<td style="vertical-align: top;">
											




											<!-- <div class="input-group w-auto align-items-center">
												<input type="button" value="-" class="button-minus border rounded-circle  icon-shape icon-sm mx-1 lh-0" data-field="quantity">
												<input type="number" step="1" max="10" value="1" name="quantity" class="quantity-field border-0 text-center w-50">
												<input type="button" value="+" class="button-plus border rounded-circle icon-shape icon-sm lh-0" data-field="quantity">
											 </div> -->

											 
                                        <!-- <div class="descr"> meethi puri <span class="badge badge-secondary"><i class="fa-solid fa-trash"></i> remove</span>  </div> -->
                                          <div class="cart-mycart"> <div class="minus"><i class="fa-solid fa-circle-minus" style="margin-right:5px"></i></div> <div class="rate">222</div> <div class="plus"><i class="fa-solid fa-circle-plus"style="margin-left:5px"></i></div> </div>
                                          <!-- <div class="price-cart">230</div> -->
                                      
                                   

											






										  </td>
										<td style="vertical-align: top; "><div style="margin-top:9px">300</div></td>
									  </tr>
									
									 
									</tbody>
								  </table>
							</div>
						</div>
							
							
							
							
							
					</div>
					  </div>
					<div class="modal-footer">
					  <!-- <button type="button" class="btn btn-success">Save</button>
					  <button type="button" class="btn btn-default close-btn" data-dismiss="modal">Close</button> -->

						<div class="container-fluid footer">
						<div class="row g-1">
							<div class="col-sm-6">Subtotal</div>
							<div class="col-sm-6 float-end">Rs. 600</div>

							<div class="col-sm-6">Tip</div>
							<div class="col-sm-6 float-end">0</div>


							<div class="col-sm-6">Delivery fee</div>
							<div class="col-sm-6 float-end">to be calculated</div>

							<div class="col-sm-6"><h4>Total</h4></div>
							<div class="col-sm-6 float-end"><h4>Rs. 600</h4></div>
						</div>
					</div>

				</div>

					<div class="modal-footer1">
						<!-- <button type="button" class="btn btn-success">Save</button>
						<button type="button" class="btn btn-default close-btn" data-dismiss="modal">Close</button> -->
  
						  <div class="container-fluid footer">
						  <div class="row g-1">
							  <div class="col-sm-12">Checkout is currently unavailable as GINO GINELLES is closed and will open at 11:00 am . Please return 
								at 11:00 am to place your order while we keep your items safely in the cart.</div>
								<p>please <strong> click here </strong> for our contact information</p>
							 
						  </div>
					  </div>
  

					  
					  
					</div>
				</div>
				  </div>
				  
				</div>
			  </div>
			  
			</div>
