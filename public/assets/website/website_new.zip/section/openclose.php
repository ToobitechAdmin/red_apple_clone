<div class="table-responsive">
                    <table class="table table-bordered mt-4 table align-middle">
                        <thead>
                            <tr class="text-center">
                                <th scope="col">Mon</th>
                                <th scope="col">Tue</th>
                                <th scope="col">Wed</th>
                                <th scope="col">Thu</th>
                                <th scope="col">Fri</th>
                                <th scope="col">Sat</th>
                                <th scope="col">Sun</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="text-center">
                                <td>11:00 am - 12:00 am</td>
                                <td>11:00 am - 12:00 am</td>
                                <td>11:00 am - 12:00 am</td>
                                <td>11:00 am - 12:00 am</td>
                                <td>11:00 am - 12:00 am</td>
                                <td>11:00 am - 12:00 am</td>
                                <td>11:00 am - 12:00 am</td>
                            </tr>
                        </tbody>
                    </table>
                </div>