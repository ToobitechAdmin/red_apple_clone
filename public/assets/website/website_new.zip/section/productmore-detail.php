<div class="container">
			
			  <!-- Trigger the modal with a button -->
			
			
			  <!-- Modal pro click menu -->
			  <div class="modal right fade" id="myModalmoreproduct-deltails" role="dialog">
				<div class="modal-dialog">
				
				  <!-- Modal content-->
				  <div class="modal-content">
					<div class="modal-header">
					  
					  <h4 class="modal-title menu" style="float: left;" ></h4>
					
					 
					 <button type="button" class="close " data-dismiss="modal" >&times;</button>
					</div>
					<div class="modal-body">
					 
						<div class="row  p-3">
						
							<img src="images/2.jpg" class="img-fluid w-100 " style="margin:auto">
							
							<div class="namerate ">
								<div class="name">Pizza .. <br>
                                <small class="muted cardpro-desc">Any specific preferences? Let us know.</small>
                            </div>
								<div class="rate">Rs. 1400</div>
							</div>
							<div class="mt-3 new2"></div>
                            <h5>Options</h5>
                            <h5>Select</h5>


                            <div class="form-check ml-3">
                            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" checked>
                            <label class="form-check-label" for="flexRadioDefault1">
                                abccc 
                            </label>
                            </div>
                            <div class="form-check  ml-3">
                            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" >
                            <label class="form-check-label" for="flexRadioDefault2">
							abccce
                            </label>
                            </div>


							<h5  class="mt-2">Special instructions</h5>
							<small class="muted">Any specific preferences? Let us know.</small>
							<div class="mt-2">
							
							<textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
							</div>
							
						</div>	
					  </div>
					<div class="modal-footer">
					  <!-- <button type="button" class="btn btn-success">Save</button>
					  <button type="button" class="btn btn-default close-btn" data-dismiss="modal">Close</button> -->
					  <!-- <p class="text-center">© 2023 redapple. All Rights Reserved.</p>
					  <br>
					  <p class="text-center">Shop powered by ....</p> -->
					  <div class="container-fluid">
						<div class="row">
						<div class="col-md-6"> <div class="cart-mycart"> <div class="minus"><i class="fa-solid fa-circle-minus" style="margin-right:5px"></i></div> <div class="rate">222</div> <div class="plus"><i class="fa-solid fa-circle-plus"style="margin-left:5px"></i></div> </div></div>
						<div class="col-md-6"><button type="button" class="btn btn-danger" id="cartdangerbtn">ADD TO CART <span><i class="fa-solid fa-arrow-right abc" style="float:right"></i></span> </button></div>
						
							
						</div>
					  </div>
					</div>
				  </div>
				  
				</div>
			  </div>
			  
			</div>
			</div>