<div class="container-fluid footer1212">
				<div class="container">
					<div class="row">
						<div class="col-sm-4">
							<div id="allright">
							<span >© 2023 GINO GINELLES. All Rights Reserved.</span>
							</div>
						</div>
						<div class="col-sm-4">
						<div id="allrightimg">
							<span id="footerstrong" class="text-center"> Shop powered by <img src="images/favicon.png " class="img-fluid w-25" id="footerimg"></span>
							</div>
						</div>
						<div class="col-sm-4">
						<div id="allrightmaster" >
						<span id="footerstrong"> Shop powered by <img src="images/mastercard.png " class="img-fluid w-25" id="footerimg"> <img src="images/visa.png " class="img-fluid w-25" id="footerimg"></span>
						</div>
						</div>
					</div>
				</div>
				<a  class="whats-app" href="https://wa.me/1234567890" target="_blank">
				<i class="fa-brands fa-whatsapp my-float"></i>
					</a>
				</div>

				
				

				<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
		
<script>
    AOS.init();
</script>