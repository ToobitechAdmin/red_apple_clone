
			<div class="container">
				<h2>&nbsp;</h2>
			  <!-- Trigger the modal with a button -->
			  <button type="button" class="btn btn-info btn-lg btn-position" data-toggle="modal" data-target="#myModal-left-tag">Click Me</button>
			
			  <!-- Modal -->
			  
			  <div class="modal left fade scroller" id="myModal-left-tag" role="dialog">
				<div class="modal-dialog tag">
				
				  <!-- Modal content-->
				  <div class="modal-content">
					
					<div class="modal-header">
						
						
					  <h4 class="modal-title menu" style="float: left;" >Menu</h4>
					
					 
					  <button type="button" class="close " data-dismiss="modal" >&times;</button>
					</div>
					<div class="modal-body">
					 
						<div class="row">
						
							<ul class="nav flex-column nav-link tag" >
								
								<li class="nav-item "  class="close " data-dismiss="modal" >
								
									<a  href="#onlineexc"  class="nav-link " > Chaat bazzar </a> 
									 
								
								</li>
							
								<li class="nav-item ">
									<a class="nav-link" href="#onlineexc">New Arrival</a>
								</li>

								<li class="nav-item ">
									<a class="nav-link" href="#" >New Arrival</a>
								</li>

								<li class="nav-item ">
									<a class="nav-link" href="#">New Arrival</a>
								</li>


								<li class="nav-item ">
									<a class="nav-link" href="#">New Arrival</a>
								</li>


								<li class="nav-item ">
									<a class="nav-link" href="#">New Arrival</a>
								</li>


								<li class="nav-item ">
									<a class="nav-link" href="#">New Arrival</a>
								</li>


								<li class="nav-item">
									<a class="nav-link" href="#">New Arrival</a>
								</li>


								<li class="nav-item ">
									<a class="nav-link" href="#">New Arrival</a>
								</li>

								<li class="nav-item ">
									<a class="nav-link" href="#">New Arrival</a>
								</li>

								<li class="nav-item ">
									<a class="nav-link" href="#">New Arrival</a>
								</li>

								<li class="nav-item ">
									<a class="nav-link" href="#">New Arrival</a>
								</li>

								<li class="nav-item ">
									<a class="nav-link" href="#">New Arrival</a>
								</li>
							
							</ul>
						
					</div>
					  </div>
				
				  </div>
				  
				</div>
			  </div>
			