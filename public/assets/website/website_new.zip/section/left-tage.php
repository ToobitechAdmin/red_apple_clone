<div class="container">
<div class="col-lg-6">
<div class="offcanvas offcanvas-start " tabindex="-1" id="offcanvas" data-bs-keyboard="false" data-bs-backdrop="false">
			<div class="offcanvas-header">
				<h6 class="offcanvas-title " id="offcanvas">Menu</h6>
				
				<span id="forcolosebtncss">
				<button type="button" class="btn-close  text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
				</span>
			</div>
			<div class="offcanvas-body px-0">
				<ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-start" id="menu">
					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close"  >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline"  id="leftagfont">chat bazzar</span>
						</a>
					</li>


					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#bazzar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >new arrival</span>
						</a>
					</li>

					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>


					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>



					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>



					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>



					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>



					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>


					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>



					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>


					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>



					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>


					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>


					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#chatbazar" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>


					<li class="nav-item lefttag" data-bs-dismiss="offcanvas" aria-label="Close" >
						<a href="#onlineexc" class="nav-link text-truncate"  >
							<i class="fs-5 bi-house"></i><span class="ms-1  d-sm-inline" id="leftagfont"  >chat bazzar</span>
						</a>
					</li>
					
				</ul>
			</div>
		</div>
		
		</div>